package borgui.editor;

import java.util.Vector;
import borgui.xml.BorealisDocument;

public interface Editor {


      public BorealisModel getModel();

     
}



