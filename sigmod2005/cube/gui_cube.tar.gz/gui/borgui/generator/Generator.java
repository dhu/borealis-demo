/**
 * Generator.java
 *
 * Created on July 20, 2005, 4:22 PM
 *
 */

package borgui.generator;

/**
 * A interface for Generator
 *
 * @author Wenjuan Xing (vivian@cs.brown.edu)
 * version 1.0 10/11/2005
 */
public interface Generator {
    
}
