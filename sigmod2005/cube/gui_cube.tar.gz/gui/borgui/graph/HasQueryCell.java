/*
 * QueryCell.java
 *
 * Created on February 6, 2006, 12:58 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package borgui.graph;

import borgui.xml.QueryElement;

/**
 *
 * @author vivian
 */
public interface HasQueryCell {
    

}
