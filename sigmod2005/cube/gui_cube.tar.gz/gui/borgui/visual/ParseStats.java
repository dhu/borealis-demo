/*
 * ParseStats.java
 *
 * Created on June 8, 2005, 8:50 PM
 */

package borgui.visual;

import java.util.*;


/**
 * 
 *
 * @author Wenjuan Xing (vivian@cs.brown.edu)
 * version 1.0 10/13/2005
 *
 */
public class ParseStats
{
    protected Vector m_stats = new Vector();
    
    /** Creates a new instance of ParseStats */
    public ParseStats(Vector  stats)
    {
        m_stats = stats;
    }
    
    public String toString()
    {
        return m_stats.toString();
    }

    //for CPU
    //Get the size of node for CPU
    public int getCpuNodeSize()
    {
        int result = 0;
        result = m_stats.size();
        //System.out.println("from 'getCpuNodeSize()':-- currentCpuNodeSize is " + result);

        return result;
    }
    
    //Get the cpu Ip and Port by index
    public String getCpuNodeIpPort(int NodeIndex)
    {
        String result = "";
        Vector Vectorx = (Vector)m_stats.get(NodeIndex);
        result = (String)Vectorx.get(0);
        //System.out.println("from 'getCpuNodeIpPort()':-- NodeIpPort is " + result);

        return result;
    }
    
    //Get cpu stat by ip and port
    public Double getCpuStats(String inputIpPort)
    {
        Double result = new Double(0);

        for (Iterator i = m_stats.iterator();i.hasNext();)
        {
            Vector current = (Vector)i.next();
            String getIpPort = (String)current.get(0);

            if (getIpPort.trim().equals(inputIpPort.trim()))
            {
                result = (Double)current.get(1);
               // System.out.println("from getCpuStats(): --Cpu from " + inputIpPort +" is "+ result);

                return result;
            }
        }

        return result;
    }
    
    
    //for Latency
    
    //get the size of node for Latency
    public int getLatencyNodeSize()
    {
        int result = 0;
        result = m_stats.size();
        //System.out.println("from 'getLatencyNodeSize()':-- LatencyNodeSize is " + result);

        return result;
    }
    
    public Vector<String>  getLatencyAllStreamName()
    {
        Vector<String> result = new Vector<String>();
        
        for (Iterator i = m_stats.iterator(); i.hasNext();)
        {
            Vector Vectorx = (Vector) i.next();
            Vector Vectorx1 = (Vector) Vectorx.get(1);
            
            for (Iterator j = Vectorx1.iterator(); j.hasNext();)
            {
                Vector Vectorx1x = (Vector) j.next();
                String name = (String) Vectorx1x.get(0);

                result.add(name);
            }
        }

        //System.out.println("new from 'getLatencyAllStreamName()':-- LatencyStream Size is " + result.size());
        return result;
    }
    
    public Double getLatencyValueByName(String streamName)
    {
        Double result = new Double(0.0);
        
        for (Iterator i = m_stats.iterator(); i.hasNext();)
        {
            Vector Vectorx = (Vector) i.next();
            Vector Vectorx1 = (Vector) Vectorx.get(1);
            
            for (Iterator j = Vectorx1.iterator(); j.hasNext();)
            {
                Vector Vectorx1x = (Vector) j.next();
                String name = (String) Vectorx1x.get(0);

                if (name.equals(streamName))
                {
                    result = (Double) Vectorx1x.get(1);
                    //System.out.println("from 'getLatencyValueByName()':-- Latency Value for Stream " + streamName +" is " + result);
                }
            }
        }

        return result;
    }
    
    public Vector<Double>  getAllLatencyValueInNodeX(String ipPort)
    {
        Vector<Double>  result = new Vector<Double>();
        
        Vector Vectorx = getLatencyVector(ipPort);

        if (Vectorx.size()!=0)
        {
            Vector Vectorx1 = (Vector) Vectorx.get(1);

            for (Iterator i = Vectorx1.iterator(); i.hasNext();)
            {
                Vector Vectorx1x = (Vector) i.next();
                Double value = (Double) Vectorx1x.get(1);
                result.add(value);
            }
        }

        return result;
    }
    
    
    protected Vector getLatencyVector(String inputIpPort)
    {
        Vector result = new Vector();

        for (Iterator i = m_stats.iterator();i.hasNext();)
        {
            Vector current = (Vector)i.next();
            String getIpPort = (String)current.get(0);

            if (getIpPort.trim().equals(inputIpPort.trim()))
            {
                result = current;
                //System.out.println("new from 'getLatencyVector()': --inputIpPort " + inputIpPort);
                return result;
            }
        }

        return result;
    }

    
    public int getLatencyStreamSize(String IpPort)
    {
        int result = 0;
        Vector Vectorx = getLatencyVector(IpPort);

        if (Vectorx.size()!=0)
        {
            Vector Vectorx1 = (Vector) Vectorx.get(1);
            result = Vectorx1.size();
            //System.out.println("new from 'getLatencyStreamSize()':--LatencyStreamSize from IpPort " + IpPort +" is " + result);
        }

        return result;
    }
    

    public String getLatencyStreamName(String IpPort, int Index)
    {
        String result = new String("");
        Vector Vectorx = getLatencyVector(IpPort);

        if (Vectorx.size()!=0)
        {
            Vector Vectorx1 = (Vector) Vectorx.get(1);
            Vector Vectorx1x = (Vector) Vectorx1.get(Index);
            result = (String) Vectorx1x.get(0);
            //System.out.println("new from 'getLatencyStreamName()': -- LatencyStreamName of Index " + Index + " is " + result);
        }

        return result;
    }
    
    public Vector<Double>  getAllTupleValueInNodeX(String ipPort)
    {
        Vector<Double>  result = new Vector<Double>();
        
        Vector Vectorx = getTupleVector(ipPort);

        if (Vectorx.size()!=0)
        {
            Vector Vectorx1 = (Vector) Vectorx.get(1);

            for (Iterator i = Vectorx1.iterator(); i.hasNext();)
            {
                Vector Vectorx1x = (Vector) i.next();
                Double value = (Double) Vectorx1x.get(1);
                result.add(value);
            }
        }

        return result;
    }

    //for tuple
    
    //get the size of node for tuple
    public int getTupleNodeSize()
    {
        int result = 0;
        result = m_stats.size();
        //System.out.println("from 'getTupleNodeSize()':-- TupleNodeSize is " + result);

        return result;
    }
    
    public Vector getTupleVector(String inputIpPort)
    {
        Vector result = new Vector();

        for (Iterator i = m_stats.iterator();i.hasNext();)
        {
            Vector current = (Vector)i.next();
            String getIpPort = (String)current.get(0);

            if (getIpPort.trim().equals(inputIpPort.trim()))
            {
                result = current;
                //System.out.println("from 'getTupleVector()': --inputIpPort " + inputIpPort);
                return result;
            }
        }

        return result;
    }
    
    //get Tuple StreamSize by IpPort
    public int getTupleStreamSize(String IpPort)
    {
        int result = 0;
        Vector Vectorx = getTupleVector(IpPort);

        if (Vectorx.size()!=0)
        {
            Vector Vectorx1 = (Vector) Vectorx.get(1);
            result = Vectorx1.size();
            //System.out.println("from 'getTupleStreamSize()':--TupleStreamSize from IpPort " + IpPort +" is " + result);
        }

        return result;
    }
    
    public String getTupleStreamName(String IpPort, int Index)
    {
        String result = "";
        
        Vector Vectorx = getTupleVector(IpPort);

        if (Vectorx.size()!=0)
        {
            Vector Vectorx1 = (Vector) Vectorx.get(1);
            Vector Vectorx1x = (Vector) Vectorx1.get(Index);
            result = (String) Vectorx1x.get(0);
            //System.out.println("from 'getTupleStreamName()': -- TupleName of Index " + Index + " is " + result);
        }

        return result;
    }
    
    public Vector<String>  getTupleAllStreamName()
    {
        Vector<String>  result = new Vector<String>();
        
        for (Iterator i = m_stats.iterator(); i.hasNext();)
        {
            Vector Vectorx = (Vector) i.next();
            Vector Vectorx1 = (Vector) Vectorx.get(1);
            
            for(Iterator j = Vectorx1.iterator(); j.hasNext();) {
                Vector Vectorx1x = (Vector) j.next();
                String name = (String) Vectorx1x.get(0);
                result.add(name);
            }
        }

        //System.out.println("from 'getTupleAllStreamName()':-- TupleStream Size is " + result.size());
        return result;
    }
    
    public Double getTupleValueByName(String streamName)
    {
        Double result = new Double(0.0);

        for (Iterator i = m_stats.iterator(); i.hasNext();)
        {
            Vector Vectorx = (Vector) i.next();
            Vector Vectorx1 = (Vector) Vectorx.get(1);
            
            for (Iterator j = Vectorx1.iterator(); j.hasNext();)
            {
                Vector Vectorx1x = (Vector) j.next();
                String name = (String) Vectorx1x.get(0);

                if (name.equals(streamName))
                {
                    result = (Double) Vectorx1x.get(1);
                 //   System.out.println("new from 'getTupleValueByName()':-- Tuple Value for Stream " + streamName +" is " + result);
                }
            }
        }

        return result;
    }
}


//////////////////////////  end ParseStats.java  ///////////////////////////////
