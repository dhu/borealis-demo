package borgui.visual;

public interface StatPlot {

	public abstract void updateCpuStats(ParseStats cpu);
    	public abstract void updateLatencyStats(ParseStats latency);
	public abstract void updateTupleStats(ParseStats tuple);

}



