package borgui.visual;

import java.awt.*;
import java.util.*;
import java.awt.event.*;
import javax.swing.event.*;

import borgui.common.*;
import borgui.visual.*;
import borgui.editor.*;
import borgui.client.*;
import borgui.graph.*;


/**
 *
 */
public class StatPlotUpdater
{
    protected Vector<StatPlot>   m_statplots = new Vector<StatPlot>();

    protected ParseStats         m_parseStatsCpu;
    protected ParseStats         m_parseStatsLatency;
    protected ParseStats         m_parseStatsTuple;

    protected XmlRpcStatHandler  m_rpcHandlerCpu     = null;
    protected XmlRpcStatHandler  m_rpcHandlerLatency = null;
    protected XmlRpcStatHandler  m_rpcHandlerTuple   = null;

 
    public StatPlotUpdater() {}

    public void setNodeIpPort(String connectIpPort)
    {
        try
        {   String connectIp   = connectIpPort.substring(0, connectIpPort.indexOf(':'));
            String connectPort = connectIpPort.substring(connectIpPort.indexOf(':')+1, connectIpPort.length());
            
            m_rpcHandlerCpu = new XmlRpcStatHandler(connectIp,
                                                    connectPort,
                                                    "QueryProcessor.get_regionCpu_statistics",
                                                    new Vector());

            m_rpcHandlerLatency = new XmlRpcStatHandler(connectIp,
                                                        connectPort,
                                                        "QueryProcessor.get_latency_statistics",
                                                        new Vector());

            m_rpcHandlerTuple = new XmlRpcStatHandler(connectIp,
                                                      connectPort,
                                                      "QueryProcessor.get_tupleDelivery_statistics",
                                                      new Vector());
        }
        catch(Exception e)
        {
            System.out.println("can not initial rpcHandler");
        }
    }


    public void addStatPlot(StatPlot p)
    {
        m_statplots.add(p);
    }


    public void updateStats()
    {
        updateCpuStats();
        updateLatencyStats();
        updateTupleStats();
    }
    
    //Make rpcs and update stats in a separate thread
    private void updateCpuStats()
    {
        final SwingWorker worker = new SwingWorker()
        {
            public Object construct()
            {
                synchronized(m_rpcHandlerCpu)
                {
                    m_parseStatsCpu =
                         new ParseStats(m_rpcHandlerCpu.getStats());
                }

                return null;
            }

                //Runs on the event-dispatching thread.
            // safely update GUI here
            public void finished()
            {
                synchronized(m_rpcHandlerCpu)
                {
                    for (Iterator i = m_statplots.iterator(); i.hasNext();)
                    {
                        StatPlot s = (StatPlot) i.next();
                        s.updateCpuStats(m_parseStatsCpu);
                    }
                }
            }
        };

        worker.start();
    }


    //Make rpcs and update stats in a separate thread
    private void updateLatencyStats()
    {
        final SwingWorker worker = new SwingWorker()
        {
            public Object construct()
            {
                synchronized(m_rpcHandlerLatency)
                {
                    m_parseStatsLatency = new ParseStats(m_rpcHandlerLatency.getStats());
                    System.out.println("Latency Ststs: " + m_parseStatsLatency.toString());
                }

                return null;
            }

            //Runs on the event-dispatching thread.
            // safely update GUI here
            public void finished()
            {
                synchronized(m_rpcHandlerLatency)
                {
                    for (Iterator i = m_statplots.iterator(); i.hasNext();)
                    {
                        StatPlot s = (StatPlot) i.next();
                        s.updateLatencyStats(m_parseStatsLatency);
                    }
                }
            }
        };

        worker.start();
    }

  
    //Make rpcs and update stats in a separate thread
    private void updateTupleStats()
    {
        final SwingWorker worker = new SwingWorker()
        {
            public Object construct()
            {
                synchronized(m_rpcHandlerTuple)
                {
                    m_parseStatsTuple = new ParseStats(m_rpcHandlerTuple.getStats());
                }

                return null;
            }

            //Runs on the event-dispatching thread.
            // safely update GUI here
            public void finished()
            {
                synchronized(m_rpcHandlerTuple)
                {
                    for (Iterator i = m_statplots.iterator(); i.hasNext();)
                    {
                        StatPlot s = (StatPlot) i.next();
                        s.updateTupleStats(m_parseStatsTuple);
                    }
                }
            }
        };

        worker.start();
    }
}


////////////////////////  end  StatPlotUpdater.java  ///////////////////////////
