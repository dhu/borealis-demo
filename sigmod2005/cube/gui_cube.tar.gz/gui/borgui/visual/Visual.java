package borgui.visual;

/**
 * 
 *
 * @author Wenjuan Xing (vivian@cs.brown.edu)
 * version 1.0 10/13/2005
 *
 */
public interface Visual {

	public void load(String filename);    
    
}



