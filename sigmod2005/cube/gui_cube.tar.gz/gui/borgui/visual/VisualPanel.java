package borgui.visual;

import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;

import borgui.editor.*;
import borgui.graph.*;
import borgui.xml.*;
import borgui.common.SwingPanel;


import java.io.*;
import org.jdom.*;
import org.xml.sax.InputSource;

import org.jgraph.graph.*;
import org.jgraph.event.GraphSelectionListener;
import org.jgraph.event.GraphSelectionEvent;



/**
 * A class that represents the visual panel.
 *
 * @author Wenjuan Xing (vivian@cs.brown.edu)
 * version 1.0 10/13/2005
 *
 */
public class VisualPanel extends JPanel implements Visual
{
    protected EditorPanel          m_editorPanel;
    protected VisualActionHandler  m_cActionHandler;

    protected JToolBar             m_jToolBar   = new JToolBar();
    protected JButton              m_loadButton = new JButton();
    protected JToggleButton        m_plotButton = new JToggleButton();

    protected ImageIcon            m_latencyImageIcon;
    protected ImageIcon            m_tempServerIcon;

    protected JScrollPane          m_graphScrollPane;
    protected VisualGraph          m_visualGraph;
    protected GraphOverviewPanel   m_graphOverview;
    protected BorealisModel        m_model;

    protected BorealisElement      m_selectedElem;

    protected ElementPanel         m_elementPanel;

    protected JTabbedPane          m_jTabbedPane = new JTabbedPane();
    protected AllPlotPanel         m_allPlotPanelTab;
    protected PlotHistory          m_historyPanelTab;
    protected PlotData             m_plotData;
    protected PlotColor            m_plotColor;

    protected ControllerPanel      m_controllerPanel   = new ControllerPanel();
    public    ServerButtonPanel    m_serverButtonPanel = new ServerButtonPanel();
    protected JTabbedPane          m_rightTabbedPane   = new JTabbedPane();
    protected XmlEditor            m_xmlEditor         = new XmlEditor();
    protected StatPlotUpdater      m_statplotUpdater   = new StatPlotUpdater();

    private   javax.swing.Timer    m_timerAllPlot;

    protected Vector<String>       m_ipPort = new Vector<String>();
    protected boolean              m_DeployXmlHasBeenLoad = false;

    //protected Vector<String>     m_totalStreamVector = new Vector<String>();


    public VisualPanel(EditorPanel editorPanel)
    {
        super();

        m_editorPanel = editorPanel;
        m_elementPanel = new ElementPanel(m_editorPanel.getModel(), false);
        m_elementPanel.setEditable(false);
        m_plotData = new PlotData(this);
        m_allPlotPanelTab = new AllPlotPanel(m_plotData);
        m_historyPanelTab = new PlotHistory(m_plotData);
        m_cActionHandler = new VisualActionHandler(this);

        try
        {   jbInit();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

        m_controllerPanel.addControllable(m_visualGraph);
        m_controllerPanel.addControllable(m_historyPanelTab);

        this.setVisible(true);
        //seem to be no use
        this.setSize(900, 700);
    }


    private void jbInit() throws Exception
    {
        //North: m_jToolBar

        m_loadButton.setIcon(new ImageIcon("images/load.gif"));
        m_loadButton.setToolTipText("Load");
        m_loadButton.addActionListener(m_cActionHandler.getAction(VisualActionHandler.LOAD_ACTION));

        m_latencyImageIcon = new ImageIcon("images/Latency.gif");
        m_plotButton.setIcon(m_latencyImageIcon);
        m_plotButton.setToolTipText("latency");
        m_plotButton.addActionListener(m_cActionHandler.getAction(VisualActionHandler.STARTSTOPPLOT_ACTION));

        m_tempServerIcon = new ImageIcon("images/laptop.gif");

        m_jToolBar.add(m_loadButton);
        m_jToolBar.add(m_plotButton);


        ModulePanel modulePanel = new ModulePanel();
        m_jToolBar.add(modulePanel);
        m_jToolBar.setFloatable(false);

        //West: leftPanel
        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.Y_AXIS));
        leftPanel.setPreferredSize(new Dimension(800, 600));

        m_visualGraph = new VisualGraph(this, m_controllerPanel);
        m_visualGraph.setPreferredSize(new Dimension(1500,1500));
        m_visualGraph.setMinimumSize(new Dimension(1500,1500));
        m_visualGraph.setBackground(Color.white);
        m_visualGraph.addGraphSelectionListener(new VisualGraphSelectionListener());
        m_graphScrollPane = new JScrollPane(m_visualGraph);
        m_graphScrollPane.setPreferredSize(new Dimension(800, 320));
        m_graphScrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
        m_graphScrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);

        leftPanel.add(m_graphScrollPane);
        leftPanel.add(m_controllerPanel);

        m_allPlotPanelTab.setPreferredSize(new Dimension(800,280));
        m_historyPanelTab.setPreferredSize(new Dimension(800, 280));
        m_jTabbedPane.addTab("Statistics",null,m_allPlotPanelTab);
        m_jTabbedPane.addTab("History",null,m_historyPanelTab);

        leftPanel.add(m_jTabbedPane);

        //East: rightPanel
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
        rightPanel.setPreferredSize(new Dimension(192, 600));


        JPanel graphOverview = GraphOverviewPanel.createGraphOverviewPanel(m_visualGraph,
                m_graphScrollPane.getViewport());
        graphOverview.setPreferredSize(new Dimension(200, 200));
        graphOverview.setMinimumSize(new Dimension(200, 200));
        graphOverview.setMaximumSize(new Dimension(200, 200));
        m_graphOverview = ((GraphOverviewPanelWrapper) graphOverview).getOverview();
        rightPanel.add(graphOverview);

        m_serverButtonPanel.setPreferredSize(new Dimension(192, 90));
        m_serverButtonPanel.setMinimumSize(new Dimension(192, 90));
        m_serverButtonPanel.setBackground(Color.white);

        rightPanel.add(m_serverButtonPanel);

        m_elementPanel.setPreferredSize(new Dimension(192, 310));
        rightPanel.add(m_elementPanel);

        this.setLayout(new BorderLayout());
        this.add(m_jToolBar, BorderLayout.NORTH);
        this.add(leftPanel, BorderLayout.WEST);
        this.add(rightPanel, BorderLayout.EAST);
        this.setPreferredSize(new Dimension(1300, 700));
        this.setVisible(true);

        m_timerAllPlot = new javax.swing.Timer(1000,
                                               new ActionListener()
            {
                public void actionPerformed(ActionEvent evt)
                {
                    m_statplotUpdater.updateStats();
                }
            }
        );


        m_model = new BorealisModel(m_editorPanel,
                                    new BorealisDocument(),
                                    m_visualGraph.getBorealisGraphModel(),
                                    m_visualGraph);
    }


    public BorealisModel getModel()
    {
        return m_model;
    }


    public void setSelectedElement(BorealisElement elem)
    {
        m_selectedElem = elem;
        m_elementPanel.setElement(m_selectedElem);
    }


    public void load()
    {
        File  file = SwingPanel.showFileDialog("Open Deployment");

        if (file != null)
        {
            load(file.getAbsolutePath());
        }
    }


    public void load(String filename)
    {
        //wenjuan test4 reload
        /*
        reload(filename);
        m_visualGraph.changeNodesColor();
         */

        //load

        try
        {   File     file = new File(filename);
            Document  doc = XmlHandler.xmlToDoc(file);

            DeployDocument  docCopy = new DeployDocument((Document)doc.clone());

            m_ipPort = docCopy.getIpPorts();

            if (m_ipPort.size() == 0)
            {
                System.out.println("Warning: can not load any ip and port");
            }
            else
            {   if (m_DeployXmlHasBeenLoad)
                {
                    int  tabcount = m_jTabbedPane.getTabCount();

                    for (int i = 0; i<tabcount-2; i++)
                    {
                        m_jTabbedPane.removeTabAt(2);
                    }

                    m_serverButtonPanel.removeAllServers();
                }

                m_plotColor = new PlotColor(m_ipPort);
                m_allPlotPanelTab.setPlotColor(m_plotColor);
                m_historyPanelTab.setPlotColor(m_plotColor);
                m_serverButtonPanel.setPlotColor(m_plotColor);
                m_serverButtonPanel.setServerIpPort(m_ipPort);
                m_statplotUpdater.setNodeIpPort((String) m_ipPort.get(0));

                m_plotData.setNodeIpPorts(m_ipPort);
                m_statplotUpdater.addStatPlot(m_allPlotPanelTab);

                int nodeIndex = 0;

                for (Iterator i = m_ipPort.iterator(); i.hasNext();)
                {
                    String ipPort = (String) i.next();
                    NodeXPlotPanel nodeXPlotPanel = new NodeXPlotPanel(ipPort, nodeIndex);
                    nodeXPlotPanel.setPlotColor(m_plotColor);
                    nodeXPlotPanel.setNodeIpPorts(m_ipPort);
                    m_statplotUpdater.addStatPlot(nodeXPlotPanel);

                    m_jTabbedPane.addTab(ipPort,nodeXPlotPanel);
                    m_visualGraph.addNode(ipPort, m_plotColor.getNodeColor(ipPort));
                    nodeIndex = nodeIndex + 1;
                }

                m_DeployXmlHasBeenLoad = true;
            }
        }
        catch (IOException e)
        {   JOptionPane.showConfirmDialog(null,
                                          e.getMessage(),
                                          "Could not open an XML file.",
                                          JOptionPane.CLOSED_OPTION,
                                          JOptionPane.ERROR_MESSAGE);
        }
        catch (Exception e)
        {   JOptionPane.showConfirmDialog(null,
                                          e.getMessage(),
                                          "XML parse error",
                                          JOptionPane.CLOSED_OPTION,
                                          JOptionPane.ERROR_MESSAGE);
        }
    }


    public void  reload(String filename)
    {
        File file = new File(filename);
        FileReader fr = null;

        try
        {
            Document  doc = XmlHandler.xmlToDoc(file);

            if (doc == null)
            {   System.err.println("File " + filename + "not found");
            }
            else
            {   m_model.getDocument().setDocument(new BorealisDocument(doc));

                String  warning =
                     BorealisModelXmlHandler.loadBorealisModel(m_model);

                if (warning != "")
                {   System.out.println("loadGraph:  " + warning);

                    JOptionPane.showConfirmDialog(null, warning,
                                                  "XML parse warning",
                                       JOptionPane.CLOSED_OPTION,
                                       JOptionPane.WARNING_MESSAGE);
                }
 
                m_graphOverview.setGraphModel(m_model.getGraphModel());
            }
        }
        catch (IOException e)
        {   JOptionPane.showConfirmDialog(null,
                                          e.getMessage(),
                                          "Could not open an XML file.",
                                          JOptionPane.CLOSED_OPTION,
                                          JOptionPane.ERROR_MESSAGE);
        }
        catch (Exception e)
        {   JOptionPane.showConfirmDialog(null,
                                          e.getMessage(),
                                          "XML parse error",
                                          JOptionPane.CLOSED_OPTION,
                                          JOptionPane.ERROR_MESSAGE);
        }
    }


    public void startStopPlot()
    {
        if (m_ipPort.size()==0)
        {
            System.out.println("from 'startStopPlot():-- Didn't get IP and Port information.");
            m_plotButton.setSelected(false);
        }
        else
        {
            if (m_timerAllPlot.isRunning())
            {
                m_timerAllPlot.stop();
            }
            else
            {   m_timerAllPlot.start();
            }
        }
    }


    private class  ModulePanel extends JPanel implements ActionListener
    {
        private final String MODULE_FILE = new String("/tmp/MetaOptimizerInstruction");


        public ModulePanel()
        {
            ButtonGroup butGroup = new ButtonGroup();
            setLayout(new BoxLayout(this, BoxLayout.X_AXIS));

            JButton noneBut = new JButton("None");
            JButton haBut = new JButton("HA");
            JButton lsBut = new JButton("Load Shedder");
            JButton lmBut = new JButton("Load Manager");
            JButton moBut = new JButton("Meta Optimizer");

            Vector<String>  dropRates = new Vector<String>();

            for (int i = 0; i <= 100; i += 10)
            {   dropRates.add(Integer.toString(i));
            }

            JComboBox lsDropValBox = new JComboBox(dropRates);
            lsDropValBox.addActionListener(new LoadListener());
            lsDropValBox.setMaximumSize(new Dimension(60, 25));
            lsDropValBox.setSelectedIndex(0);

            noneBut.setActionCommand("None");
            haBut.setActionCommand("HA");
            lsBut.setActionCommand("LoadShedder");
            lmBut.setActionCommand("LoadManager");
            moBut.setActionCommand("MetaOptimizer");

            noneBut.addActionListener(this);
            haBut.addActionListener(this);
            lsBut.addActionListener(this);
            lmBut.addActionListener(this);
            moBut.addActionListener(this);

            butGroup.add(noneBut);
            butGroup.add(haBut);
            butGroup.add(lsBut);
            butGroup.add(lmBut);
            butGroup.add(moBut);

            add(noneBut);
            add(haBut);
            add(lsBut);
            add(lsDropValBox);
            add(lmBut);
            add(moBut);

            noneBut.setSelected(true);
        }


        public void actionPerformed(ActionEvent e)
        {
            String command = e.getActionCommand();

            try
            {
                FileWriter fw = new FileWriter(MODULE_FILE, false);
                fw.write(command);
                fw.flush();
                fw.close();
            }
            catch(java.io.IOException excep)
            {
                System.out.println(excep.getMessage());
            }
        }
    }


    private class LoadListener implements ActionListener
    {
        private final String LOAD_FILE = new String(
                  System.getProperty("java.io.tmpdir") + "LoadLevel");

        public void actionPerformed(ActionEvent e)
        {
            try
            {
                FileWriter fw = new FileWriter(LOAD_FILE, false);
                fw.write((String) ((JComboBox) e.getSource()).getSelectedItem());
                fw.flush();
                fw.close();
            }
            catch(java.io.IOException excep)
            {
                System.out.println(excep.getMessage());
            }
        }
    }


    private class VisualGraphSelectionListener implements GraphSelectionListener
    {
        protected HashMap<String,BorealisEdge>  m_streams =
                                            new HashMap<String,BorealisEdge>();

        public void valueChanged(GraphSelectionEvent e)
        {
            BorealisElement elem = null;
            BorealisModel model = getModel();

            Object[] selectedCells = e.getCells();


            // handle single clicking on stream case
            if ((selectedCells.length == 1) && (selectedCells[0] instanceof BorealisEdge))
            {
                BorealisEdge edge = (BorealisEdge) selectedCells[0];
                Object obj = edge.getSource();

                if (obj instanceof OutputPort)
                {
                    GraphCell cell = ((OutputPort)obj).getParentCell();
                    elem = model.getElement(cell);
                    String stream = ((StreamAttributeElement) elem).getStream();

                    m_streams.put(stream, edge);
                    Vector<String> showStreamVector = new Vector<String>(m_streams.keySet());
                    // temp hack

                    if (m_plotColor != null)
                    {
                        m_plotColor.refreshShowStreamVector(showStreamVector);
                        m_allPlotPanelTab.refreshStreamVector(showStreamVector);
                        m_historyPanelTab.refreshStreamVector(showStreamVector);
                        m_plotData.refreshStreamVector(showStreamVector);

                        for (int i = 0; i<m_jTabbedPane.getTabCount()-2; i++)
                        {
                            NodeXPlotPanel tabComponent = (NodeXPlotPanel)  m_jTabbedPane.getComponentAt(2+i);
                            tabComponent.refreshStreamVector(showStreamVector);
                        }
                    }
                }
            }

            for(int i = 0; i < selectedCells.length && elem == null; i++)
            {
                Object cell = selectedCells[i];
                // if a graph cell

                if (cell instanceof BorealisGraphCell)
                {
                    BorealisGraphCell graphCell = (BorealisGraphCell) cell;
                    elem = model.getElement(graphCell);
                }
            }

            if (elem != null)
            {   setSelectedElement(elem);
            }
        }
    }
}


///////////////////////////  end VisualPanel.java  /////////////////////////////
