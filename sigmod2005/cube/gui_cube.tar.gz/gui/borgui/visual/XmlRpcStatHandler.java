/*
 * StatisticsHandler.java
 *
 * Created on May 23, 2005, 3:20 PM
 */

package borgui.visual;

import medusaXmlRpc.*;
import java.util.Vector;
import java.util.Iterator;


/**
 * 
 *
 * @author Wenjuan Xing (vivian@cs.brown.edu)
 * version 1.0 10/13/2005
 *
 */
public class XmlRpcStatHandler
{
    protected ServerNode  m_serverNode;
    protected String      m_methodName = "";
    protected Vector      m_parameter  = new Vector();
    
    
    /** Creates a new instance of StatisticsHandler */
    public XmlRpcStatHandler(String   ipAddress,
                             String   portNumber,
                             String   methodName,
                             Vector   parameter)
    {
        m_serverNode = new ServerNode(ipAddress,portNumber);
        m_methodName = methodName;
        m_parameter  = parameter;
        
    }
    
    public Vector  getStats()
    {
        Vector  result = new Vector();

        try
        {   System.out.println("GET STATS FOR: " + m_methodName);

            Vector Stats = (Vector)MedusaXmlRpc.invoke(m_serverNode.serverRPC(),
                                                       m_methodName,
                                                       m_parameter);

            if (Stats.size()!=0)
            {
                System.out.println("from 'getStats()':-- Successfully invoke XML RPC and get Stats");
            }
            else
            {   System.out.println("from getStats():--Stats.size = 0");
            }

            result = Stats;
            //return result;
            
        }
        catch(Exception e)
        {
            //e.printStackTrace();
            System.out.println("from 'getCpuNodeSize()':-- wrong invoke");
        }

        return result;
    }
}


/////////////////////// end XmlRpcStatHandler.java  ////////////////////////////
