package borgui.xml;

import java.util.EventObject;

public class BorealisDocumentEvent extends EventObject {

	public BorealisDocumentEvent(Object source) {
		super(source);
	}

}
