package borgui.xml;

import org.jdom.*;
import java.util.*;
import borgui.graph.*;
import borgui.editor.*;
import org.jgraph.graph.*;
import org.jgraph.JGraph;


/**
 * A Class with convenience methods for dealing with jdom documents as
 * well as encoding and decoding graphical state into and out of a document
 *
 */
public class BorealisModelXmlHandler
{
    public static JGraph m_localGraph = new JGraph();

    public static org.jgraph.layout.SugiyamaLayoutAlgorithm m_layout =
            new org.jgraph.layout.SugiyamaLayoutAlgorithm();
    
    /**
     * Default Constructor
     */
    public BorealisModelXmlHandler() {}
    
    /*
    public static void borealisModelToXml(BorealisModel model) {}
    
    public static void xmlToBorealisModel(Document doc) {}
    */
    

    ////////////////////////////////////////////////////////////////////////////
    //
    //  Transform a parsed XML document (referenced in a model) to a graph.
    //  Returns an empty string if all is well.
    //  The first warning encountered is returned if there were warnings.
    //  If the graph could not be loaded due to an error, an Exception is
    //  thrown and the graph is cleared.
    //  
    public static String  loadBorealisModel(BorealisModel  model)
                  throws  Exception
    {
        String  warning = "";          // Assume no warnings.
    //..........................................................................


        // clear
        model.clearElementMap();
        model.clearCellMap();

        // make a local copy
        BorealisGraphModel graphModel = new BorealisGraphModel();
        model.setGraphModel(graphModel);
        BorealisDocument doc = model.getDocument();
        
        graphModel.setBuffering(true);
        
        // maps to create connections with
        // map of "stream"(edge name) to the graph cell (to its import port)
        HashMap<String, GraphCell>  edgeToTargetCell =
                                new HashMap<String, GraphCell>();

        // map of "stream"(edge name) to the graph cell (to its output port)
        HashMap<String, GraphCell>  edgeToSourceCell =
                                new HashMap<String, GraphCell>();

        // schemas and queries have no graph representation

        // get all inputs
        List inputElements = doc.getAllInputs();

        // Go through each input element.
        //
        for (Iterator i = inputElements.iterator(); i.hasNext();)
        {
            InputElement inputElem = (InputElement) i.next();

            // create graph object
            InputGraphCell inputCell = new InputGraphCell();
            inputCell.setUserObject(inputElem.getStream());
            graphModel.insertCell(inputCell);

            // add model mapping
            model.addMapping(inputElem, inputCell);

            // add port mapping
            edgeToSourceCell.put(inputElem.getStream(), inputCell);
        }
        
        // Scan all outputs.
        //
        List outputElements = doc.getAllOutputs();

        for (Iterator i = outputElements.iterator(); i.hasNext();)
        {
            OutputElement outputElem = (OutputElement) i.next();

            // create graph object
            OutputGraphCell outputCell = new OutputGraphCell();
            outputCell.setUserObject(outputElem.getStream());
            graphModel.insertCell(outputCell);

            // add model mapping
            model.addMapping(outputElem, outputCell);

            // add port mapping
            edgeToTargetCell.put(outputElem.getStream(), outputCell);
        }
        
        // Scan all tables
        //
        List tableElements = doc.getAllTables();

        for(Iterator i = tableElements.iterator(); i.hasNext();)
        {
            TableElement tableElem = (TableElement) i.next();

            // create graph object
            TableGraphCell tableCell = new TableGraphCell();
            tableCell.setUserObject(tableElem.getNameValue());
            graphModel.insertCell(tableCell);

            // add model mapping
            model.addMapping(tableElem, tableCell);
            
            // add port mapping
            edgeToTargetCell.put(tableElem.getStream(), tableCell);
        }
        
        
        // get all boxes
        List  boxElements = doc.getAllBoxes();
        BorealisGraphCellFactory fact = new BorealisGraphCellFactory();

        // get all outputs
        for (Iterator i = boxElements.iterator(); i.hasNext();)
        {
            BoxElement boxElem = (BoxElement) i.next();

            // create graph object
            BoxGraphCell boxCell = fact.createBox(boxElem);
            boxCell.setUserObject(boxElem.getNameValue());
            graphModel.insertCell(boxCell);

            // add model mapping
            model.addMapping(boxElem, boxCell);
            
            // handle ins
            List ins = boxElem.getAllIns();

            for (Iterator j = ins.iterator(); j.hasNext();)
            {
                InElement inElem = (InElement) j.next();
                edgeToTargetCell.put(inElem.getStream(), boxCell);
            }
            
            // handle outs
            List outs = boxElem.getAllOuts();

            for (Iterator j = outs.iterator(); j.hasNext();)
            {
                OutElement outElem = (OutElement) j.next();
                edgeToSourceCell.put(outElem.getStream(), boxCell);
            }
            
            // ADD TABLE PORT SUPPORT
            TablerefElement refs = boxElem.getTableref();

            if (refs!=null)
            {
                boxCell.setTableBox(true);
                TablerefPort refPort = boxCell.getTablerefPort();
                String tableName = refs.getTableAttribute();
                String streamName = "";

                for (Iterator j = tableElements.iterator(); j.hasNext();)
                {
                    TableElement tableElement = (TableElement) j.next();

                    if (tableElement.getNameValue().equals(tableName))
                    {
                        streamName = tableElement.getStream();
                    }
                }
                
                // add port mapping
                edgeToSourceCell.put(streamName, boxCell);
            }
        }

        // make connections
        // go through all outs and connect
        // ??? fails on an incomplete graph.
        Set streams = edgeToSourceCell.keySet();
        //Set streams = edgeToTargetCell.keySet();

        for (Iterator i = streams.iterator(); i.hasNext(); )
        {
            String  edgeName = (String)i.next();
            
            BorealisGraphCell  targetCell =
                            (BorealisGraphCell)edgeToTargetCell.get(edgeName);

            if (targetCell == null)
            {   if (warning == null)
                {   warning = "Stream ("+ edgeName + ") is not connected.";
                    System.out.println(warning);
                }
            }
            else
            {   BorealisGraphCell sourceCell =
                            (BorealisGraphCell) edgeToSourceCell.get(edgeName);

                if (!(targetCell instanceof TableGraphCell))
                {
                    graphModel.connect(sourceCell.getOutputPort(),
                                       targetCell.getInputPort(), edgeName);
                }
                else
                {   graphModel.connect(((BoxGraphCell)sourceCell).getTablerefPort(),
                                       ((TableGraphCell)targetCell).getTablePort(),
                                       edgeName);
                }
            }
        }

        graphModel.flushBuffer();
        graphModel.setBuffering(false);
        m_layout.setVertical(false);

        m_localGraph.setModel(graphModel);

        try
        {   m_layout.run(m_localGraph, DefaultGraphModel.getAll(graphModel), new Object[0]);
            
        }
        catch(Exception e)
        {   System.out.println("loadBorealisModel:  " + e.getMessage());
            model.setGraphModel(null);

            throw  new Exception(e.getMessage());
        }

        return  warning;
    }
}


/////////////////////  end BorealisModelXmlHandler.java  ///////////////////////
