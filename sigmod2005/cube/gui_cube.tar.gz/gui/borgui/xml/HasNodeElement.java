/*
 * HasNodeElement.java
 *
 * Created on February 8, 2006, 12:26 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package borgui.xml;

/**
 *
 * @author vivian
 */
public interface HasNodeElement
{
    public String getNodeAttribute();


    public void setNodeAttribute(String value);
}


/////////////////////////  end  HasNodeElement.java  ///////////////////////////
