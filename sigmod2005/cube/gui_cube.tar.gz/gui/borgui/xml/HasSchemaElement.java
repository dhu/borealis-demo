/*
 * HasSchemaElement.java
 *
 * Created on February 8, 2006, 12:07 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package borgui.xml;

/**
 *
 * @author vivian
 */
public interface HasSchemaElement
{
    public String getSchema();


    public void setSchema(String value);
}


////////////////////////  end  HasSchemaElem.java  /////////////////////////////
