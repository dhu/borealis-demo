#!/bin/sh
javadoc -d javadocs/ -sourcepath ./ -subpackages borgui
